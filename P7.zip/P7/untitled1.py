#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 16:13:46 2017

@author: leonvillapun
"""

net = jpype.JClass("smile.Network")

